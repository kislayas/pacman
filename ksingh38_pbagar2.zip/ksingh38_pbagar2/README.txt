Here is the group detail:

Name: Kislaya Kumar Singh
Net ID: ksingh38
"""""""""""""""""""""""""""""""""""""
Name: Pratyush Bagaria
Net ID: pbagar2
